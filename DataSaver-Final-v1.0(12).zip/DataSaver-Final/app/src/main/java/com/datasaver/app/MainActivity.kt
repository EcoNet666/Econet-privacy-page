package com.datasaver.app

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import kotlin.math.roundToInt

data class AppUsage(val name: String, val bytes: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DataSaverApp(this) }
    }
}

@Composable
fun DataSaverApp(context: Context) {
    var limitGb by remember { mutableFloatStateOf(5f) }
    var used by remember { mutableLongStateOf(0L) }
    var apps by remember { mutableStateOf(emptyList<AppUsage>()) }
    var permission by remember { mutableStateOf(hasUsageAccess(context)) }

    fun refresh() {
        permission = hasUsageAccess(context)
        if (permission) {
            used = getMobileDataUsage(context)
            apps = getAppUsage(context).take(10)
        }
    }

    LaunchedEffect(Unit) { refresh() }

    val limitBytes = (limitGb * 1024 * 1024 * 1024).toLong()
    val percent = if (limitBytes > 0) {
        ((used.toDouble() / limitBytes) * 100).coerceIn(0.0, 100.0)
    } else 0.0
    val remaining = (limitBytes - used).coerceAtLeast(0)

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(20.dp)
            ) {
                Text("DataSaver", fontSize = 32.sp)
                Text("Seu consumo de internet sob controle", fontSize = 15.sp)

                Spacer(Modifier.height(22.dp))

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Consumo mensal", fontSize = 18.sp)
                        Text(formatBytes(used), fontSize = 36.sp)
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { (percent / 100).toFloat() },
                            Modifier.fillMaxWidth().height(10.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("${percent.roundToInt()}% do limite • Restante: ${formatBytes(remaining)}")
                    }
                }

                Spacer(Modifier.height(16.dp))

                if (!permission) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Ative o monitoramento", fontSize = 19.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("O Android precisa permitir que o DataSaver consulte as estatísticas de uso.")
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                                },
                                Modifier.fillMaxWidth()
                            ) { Text("Conceder permissão") }
                        }
                    }
                } else {
                    Text("Limite mensal: ${limitGb.toInt()} GB", fontSize = 18.sp)
                    Slider(
                        value = limitGb,
                        onValueChange = { limitGb = it },
                        valueRange = 1f..100f,
                        steps = 98
                    )

                    val warning = percent >= 80
                    if (warning) {
                        Text(
                            if (percent >= 100) "⚠ Limite de dados atingido" else "⚠ Você já usou 80% ou mais do limite",
                            fontSize = 16.sp
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    Text("Aplicativos que mais usam dados", fontSize = 20.sp)

                    Spacer(Modifier.height(6.dp))
                    LazyColumn(
                        Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        items(apps) { app ->
                            Card(Modifier.fillMaxWidth()) {
                                Row(
                                    Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(app.name, Modifier.weight(1f), fontSize = 16.sp)
                                    Text(formatBytes(app.bytes))
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { refresh() },
                        Modifier.fillMaxWidth()
                    ) { Text("Atualizar") }

                    Spacer(Modifier.height(7.dp))

                    OutlinedButton(
                        onClick = {
                            context.startActivity(Intent(Settings.ACTION_DATA_SAVER_SETTINGS))
                        },
                        Modifier.fillMaxWidth()
                    ) { Text("⚡ Abrir Economia de dados do Android") }
                }
            }
        }
    }
}

fun getMobileDataUsage(context: Context): Long = try {
    val manager = context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
    val r = monthRange()
    val s = manager.querySummaryForDevice(ConnectivityManager.TYPE_MOBILE, null, r.first, r.second)
    s.rxBytes + s.txBytes
} catch (_: Exception) { 0L }

fun getAppUsage(context: Context): List<AppUsage> = try {
    val manager = context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
    val r = monthRange()
    val stats = manager.querySummary(ConnectivityManager.TYPE_MOBILE, null, r.first, r.second)
    val bucket = NetworkStats.Bucket()
    val result = mutableListOf<AppUsage>()

    while (stats.hasNextBucket()) {
        stats.getNextBucket(bucket)
        val uid = bucket.uid
        val bytes = bucket.rxBytes + bucket.txBytes
        if (uid <= 0 || bytes <= 0) continue

        val name = try {
            val packages = context.packageManager.getPackagesForUid(uid)
            if (!packages.isNullOrEmpty()) {
                val info = context.packageManager.getApplicationInfo(packages[0], 0)
                context.packageManager.getApplicationLabel(info).toString()
            } else "UID $uid"
        } catch (_: Exception) { "UID $uid" }

        result.add(AppUsage(name, bytes))
    }
    stats.close()
    result.groupBy { it.name }
        .map { (name, list) -> AppUsage(name, list.sumOf { it.bytes }) }
        .sortedByDescending { it.bytes }
} catch (_: Exception) { emptyList() }

fun monthRange(): Pair<Long, Long> {
    val c = Calendar.getInstance()
    c.set(Calendar.DAY_OF_MONTH, 1)
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis to System.currentTimeMillis()
}

fun hasUsageAccess(context: Context): Boolean {
    val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    return ops.unsafeCheckOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS,
        Process.myUid(),
        context.packageName
    ) == AppOpsManager.MODE_ALLOWED
}

fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    bytes < 1024 * 1024 * 1024 -> "${bytes / (1024 * 1024)} MB"
    else -> String.format("%.2f GB", bytes.toDouble() / (1024 * 1024 * 1024))
}
