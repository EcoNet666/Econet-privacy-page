# DataSaver — Produto final V1.0

Aplicativo Android para ajudar o usuário a acompanhar e reduzir o consumo de dados móveis.

## Recursos
- Consumo total de dados móveis desde o início do mês.
- Limite mensal configurável de 1 a 100 GB.
- Indicador visual de utilização.
- Aviso quando o consumo chega a 80% e quando ultrapassa o limite.
- Ranking dos aplicativos que mais consumiram dados móveis.
- Atalho para a Economia de dados nativa do Android.
- Interface simples e leve.

## Instalação
Abra a pasta no Android Studio, sincronize o Gradle e execute em um aparelho Android.
Na primeira abertura, conceda "Acesso ao uso" ao DataSaver.

## Observação técnica
O Android controla o acesso às estatísticas de rede. A precisão e a disponibilidade dos dados podem variar conforme fabricante, versão do Android e configurações do aparelho. O aplicativo não consegue reduzir arbitrariamente os dados de outros aplicativos; ele usa recursos e configurações permitidos pelo Android.
